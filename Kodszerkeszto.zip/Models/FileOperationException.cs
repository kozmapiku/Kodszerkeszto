﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kodszerkeszto.Models
{
    public class FileOperationException : Exception
    {
        public FileOperationException() { }
    }
}
